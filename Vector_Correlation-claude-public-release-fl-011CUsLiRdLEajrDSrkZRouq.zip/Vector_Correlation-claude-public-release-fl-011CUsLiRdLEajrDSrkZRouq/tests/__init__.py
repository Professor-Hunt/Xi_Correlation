"""Unit tests for Vector Correlation project."""
